<footer class="footer">
    <div class="container-fluid bg-dark">
        <div class="row text-muted">
            <div class="col-12 text-center p-2">
                <p class="mb-0 text-white">
                    &copy; <a class="border-bottom" href="">NovelNest</a>, All Right Reserved.
                </p>
            </div>

        </div>
    </div>
</footer>