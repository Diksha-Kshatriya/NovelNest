<nav class="navbar navbar-expand px-3 border-bottom">
      <button class="btn" id="sidebar-toggle" type="button">
         <span class="navbar-toggler-icon"></span>
      </button>
      <div class="navbar-collapse navbar">
         <ul class="navbar-nav">
            <li class="nav-item dropdown">
               <a href="logout.php" class="btn btn-sm btn-primary px-2">
                  <i class="fa fa-sign-out"></i> Logout
               </a>
            </li>
         </ul>
      </div>
   </nav>