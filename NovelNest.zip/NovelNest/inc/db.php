<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "novelbook";

$conn = new mysqli($server, $username, $password, $db);


?>